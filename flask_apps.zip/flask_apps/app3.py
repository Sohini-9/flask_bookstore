#this program is for using loops
from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
import os

#for the database purpose 
project_dir = os.path.dirname(os.path.abspath(__file__))
database_file = "sqlite:///{}".format(os.path.join(project_dir,"mydatabase.db"))

app = Flask(__name__)

#connection of the database to the app
app.config["SQLALCHEMY_DATABASE_URI"] = database_file
db = SQLAlchemy(app)

#creating model for the database purpose
class Book(db.Model):
    name = db.Column(db.String(100),unique=True,nullable=False,primary_key=True)   #nullable is like whether this field can be left null or not
    author = db.Column(db.String(100),unique=True,nullable=False)



app.app_context().push()
db.create_all()



@app.route("/")

def index():
    return render_template("index.html")

@app.route('/profile/<username>')
def profile(username):
    
    return render_template('profile.html',username=username,isActive=True)

@app.route('/books')
def books():
    #books = ['Book1','Book2','Book3']
    books = Book.query.all() #queries all the books from the database
    return render_template('books.html',books=books)

@app.route('/addbook')
def addbook():
    return render_template('addbook.html')

@app.route('/submitbook', methods=['POST'])
def submitbook():
    name = request.form['name']
    author = request.form['author']
    book = Book(name=name,author=author)
    db.session.add(book)
    db.session.commit()
    return 'Data has been submitted successfully Chukaheeee!!! Book name is %s and author name is %s' %(name,author)

if __name__ == "__main__":
    app.run(debug=True)