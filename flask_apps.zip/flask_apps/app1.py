

#this program is for rendering to the other pages which can be html
from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")

def index():
    return render_template("index.html")

@app.route('/profile/<username>')
def profile(username):
    
    return render_template('profile.html',username=username,isActive=True)

app.run(debug=True)