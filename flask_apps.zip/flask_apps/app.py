from flask import Flask, request
# from flask import Flask, redirect, url_for


app = Flask(__name__)  #this is an app instance ... name is passed so that flask can determine the location of the application

'''
@app.route('/')

def home():
    return '<h1>This is an index pages</h1>'
'''
@app.route('/new')

def new():
    return 'This is a new page'
'''
@app.route('/profile/john')
def profile():
    return '<h1>This is a profile page</h1>'

'''

#for making the profiles dynamic
@app.route('/profile/<username>')
def profile(username):
    return '<h1>This is a profile page for %s</h1>' %username

#for making the profiles dynamic using user id
@app.route('/profiles/<int:id>')
def profiles(id):
    return '<h1>This is a profile page for %d</h1>' %id

@app.route('/admin')
def welcome_admin():
    return 'Welcome Admin'

@app.route('/guest/<guest>')
def welcome_guest(guest):
    return "Welcome guest %s" %guest

'''the below function decides whether user will be a guest or an admin
@app.route('/user/<name>')
def welcome_user(name):
    if name == 'admin':
        return redirect(url_for('welcome_admin'))
    else:
        return redirect(url_for('welcome_guest',guest=name))
'''
#receiving requests example
@app.route('/')
def index():
    return 'This is the request made by the client %s' %request.headers

app.run(debug=True)   #it helps to run the application