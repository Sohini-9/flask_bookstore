#this program is for using loops
from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy
import os



app = Flask(__name__)


@app.route("/")

def index():
    return render_template("index.html")

@app.route('/profile/<username>')
def profile(username):
    
    return render_template('profile.html',username=username,isActive=True)

@app.route('/books')
def books():
    #books = ['Book1','Book2','Book3']
    books = [{'name':'Book1', 'author':'Author 1','cover':'https://cdn3.vectorstock.com/i/1000x1000/58/37/modern-abstract-book-cover-template-vector-16375837.jpg'},
             {'name':'Book2', 'author':'Author 2','cover':'https://cdn3.vectorstock.com/i/1000x1000/58/37/modern-abstract-book-cover-template-vector-16375837.jpg'},
             {'name':'Book3', 'author':'Author 3','cover':'https://cdn3.vectorstock.com/i/1000x1000/58/37/modern-abstract-book-cover-template-vector-16375837.jpg'}]
    return render_template('books.html',books=books)

@app.route('/addbook')
def addbook():
    return render_template('addbook.html')

@app.route('/submitbook', methods=['POST'])
def submitbook():
    name = request.form['name']
    author = request.form['author']
    return 'Book name is %s and author name is %s' %(name,author)

app.run(debug=True)